package com.verygood.island.entity.vo;

import com.verygood.island.entity.Message;
import lombok.Data;

@Data
public class MessageVo extends Message {
    private String nickname;
}
