package com.verygood.island;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IslandApplicationTests {

    @Test
    void contextLoads() {
    }

}
